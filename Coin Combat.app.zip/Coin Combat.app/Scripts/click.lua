local gui = require("GUI")

gui.alert("Поздровляю Ты выйграл, один лол коин!")
